﻿# Package
my_project/
├── my_package/
│   ├── __init__.py
│   └── main.py
├── README.md
├── LICENSE
├── setup.py
└── requirements.txt